package com.payroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
